#include "operations.h"

void operation1(char* inFileName, char* outFileName) {
    if(readCsvFile(inFileName) && writeBinFile(outFileName))
        binarioNaTela(outFileName);
}

/*void operation2(char* inFileName) {
    printFileInfo(inFileName);
}

void operation3(char* inFileName, int numberOfSearches) {
    searchBinFile(inFileName, numberOfSearches);
}*/
