#include "registers.h"

struct headerRegister {
    char status[2];
    long long top;
    long long nextByteOffset;
    int onRegistersNumber;
    int offRegistersNumber;
};

struct dataRegister {
    char removed[2];
    int registerSize;
    long long nextRegister;
    int playerId;
    int playerAge;
    int playerNameSize;
    char* playerName;
    int playerNatSize;
    char* playerNat;
    int playerClubSize;
    char* playerClub;
};

HEADER* header;
DATA** data;

HEADER* createHeader(int registerNumber) {
    HEADER* header1;

    if((header1 = (HEADER*) malloc(sizeof(HEADER))) == NULL) {
        printf("Falha no processamento do arquivo.");
        return NULL;
    }

    (header1->status)[0] = '0';
    (header1->status)[1] = '\0';
    header1->top = -1;
    header1->nextByteOffset = 0;
    header1->onRegistersNumber = registerNumber;
    header1->offRegistersNumber = 0;

    return header1;
}

DATA** createData(int registerNumber) {
    DATA** data1;

    if((data1 = (DATA**) malloc(registerNumber * sizeof(DATA*))) == NULL) {
        printf("Falha no processamento do arquivo.");
        return NULL;
    }

    for(int i = 0; i < registerNumber; i++) {
        if((data1[i] = (DATA*) malloc(sizeof(DATA))) == NULL) {
            printf("Falha no processamento do arquivo.");
            return NULL;
        }
        data1[i]->playerName = (char*) malloc(40 * sizeof(char));
        data1[i]->playerNat = (char*) malloc(40 * sizeof(char));
        data1[i]->playerClub = (char*) malloc(40 * sizeof(char));
    }

    return data1;
}

bool storeCsvInfo(char** registers, int registerNumber) {
    header = createHeader(registerNumber);
    data = createData(registerNumber);

    if((header == NULL) || (data == NULL)) {
        printf("Falha no processamento do arquivo.");
        return false;
    }

    char* string;
    int nameSize, natSize, clubSize, begin, i;

    begin = i = 0;

    for(i = 0; i < registerNumber; i++) {
        //printf("%s\n", registers[i]);
        (data[i]->removed)[0] = '0';
        (data[i]->removed)[1] = '\0';

        string = strtok(registers[i], ",");
        if(string != NULL) {
            //printf("%s ", string);
            data[i]->playerId = atoi(string);
        }
        else {
            data[i]->playerId = -1;
        }

        string = strtok(NULL, ",");
        if(string != NULL) {
            //printf("%s ", string);
            data[i]->playerAge = atoi(string);
        }
        else {
            data[i]->playerAge = -1;
        }

        string = strtok(NULL, ",");
        if(string != NULL) {
            nameSize = strlen(string);
            //printf("%s ", string);
            strcpy(data[i]->playerName, string);
        }
        else {
            nameSize = 0;
            data[i]->playerName = "Nulo";
        }

        string = strtok(NULL, ",");
        if(string != NULL) {
            natSize = strlen(string);
            //printf("%s ", string);
            strcpy(data[i]->playerNat, string);
        }
        else {
            natSize = 0;
            data[i]->playerNat = "Nulo";
        }

        string = strtok(NULL, ",");
        if(string != NULL) {
            clubSize = strlen(string);
            //printf("%s \n", string);
            strcpy(data[i]->playerClub, string);
        }
        else {
            clubSize = 0;
            data[i]->playerClub = "Nulo";
        }

        data[i]->playerNameSize = nameSize;
        data[i]->playerNatSize = natSize;
        data[i]->playerClubSize = clubSize;

        data[i]->registerSize = 33 + nameSize + natSize + clubSize;
        data[i]->nextRegister = data[i]->registerSize + begin;

        begin = data[i]->nextRegister;
    }

    (header->status)[0] = '1';
    (header->status)[1] = '\0';

    header->nextByteOffset = data[i - 1]->nextRegister;
    
    return true;
}

// Dividir em 2 procedimentos (talvez)
void writeBinHeader(FILE* outFile) {
    fwrite(&((header->status)[0]), sizeof(char), 1, outFile);
    fwrite(&(header->top), sizeof(long long), 1, outFile);
    fwrite(&(header->nextByteOffset), sizeof(long long), 1, outFile);
    fwrite(&(header->onRegistersNumber), sizeof(int), 1, outFile);
    fwrite(&(header->offRegistersNumber), sizeof(int), 1, outFile);

    printf("%c %lld %lld %d %d\n", (header->status)[0], header->top, header->nextByteOffset, header->onRegistersNumber, header->offRegistersNumber);
}

void writeBinData(FILE* outFile) {
    for(int i = 0; i < header->onRegistersNumber; i++) {
        fwrite(&(data[i]->removed[0]), sizeof(char), 1, outFile);
        fwrite(&(data[i]->registerSize), sizeof(int), 1, outFile);
        fwrite(&(data[i]->nextRegister), sizeof(long long), 1, outFile);
        fwrite(&(data[i]->playerId), sizeof(int), 1, outFile);
        fwrite(&(data[i]->playerAge), sizeof(int), 1, outFile);
        fwrite(&(data[i]->playerNameSize), sizeof(int), 1, outFile);
        fwrite(data[i]->playerName, data[i]->playerNameSize * sizeof(char), 1, outFile);
        fwrite(&(data[i]->playerNatSize), sizeof(int), 1, outFile);
        fwrite(data[i]->playerNat, data[i]->playerNatSize * sizeof(char), 1, outFile);
        fwrite(&(data[i]->playerClubSize), sizeof(int), 1, outFile);
        fwrite(data[i]->playerClub, data[i]->playerClubSize * sizeof(char), 1, outFile);

        
        
        
        
        
        printf("%c %d %lld %d %d %d %s %d %s %d %s\n", data[i]->removed[0], data[i]->registerSize, data[i]->nextRegister, data[i]->playerId, data[i]->playerAge, data[i]->playerNameSize, data[i]->playerName, data[i]->playerNatSize, data[i]->playerNat, data[i]->playerClubSize, data[i]->playerClub);       
    }

    freeMemoryData(&data, header->onRegistersNumber);
    freeMemoryHeader(&header);
}

void freeMemoryHeader(HEADER** header) {
    free(*header);
    *header = NULL;
}

void freeMemoryData(DATA*** data, int registers) {
    for(int i = 0; i < registers; i++) {
        if((*data)[i] != NULL) {
            if(((*data)[i]->playerNameSize) != 0)
                free((*data)[i]->playerName);
            if(((*data)[i]->playerNatSize) != 0)
                free((*data)[i]->playerNat);
            if(((*data)[i]->playerClubSize) != 0)
                free((*data)[i]->playerClub);
            free((*data)[i]);
            (*data)[i] = NULL;
        }
    }

    free(*data);
    *data = NULL;
}