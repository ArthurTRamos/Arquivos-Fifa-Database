#ifndef REGISTERS_H
    #define REGISTERS_H

    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <stdbool.h>

    typedef struct headerRegister HEADER;
    typedef struct dataRegister DATA;

    HEADER* createHeader(int registerNumber);
    DATA** createData(int registerNumber);
    bool storeCsvInfo(char** registers, int registerNumber);
    void writeBinHeader(FILE* outFile);
    void writeBinData(FILE* outFile);
    void freeMemoryHeader(HEADER** header);
    void freeMemoryData(DATA*** data, int registers);

#endif