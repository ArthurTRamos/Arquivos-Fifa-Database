/*
    Grupo:
        Arthur Trottmann Ramos - 14681052
        Henrique Drago - 14675441

    Arquivo:
        Programa principal e de leitura de Entradas. Redireciona
        para as operações, funções e procedimentos específicos
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "operations.h"

int main(void) {
    // Variáveis para o número da funcionalidade (de 1 a 3) e
    // o número de buscas (para funcionalidade 3)
    int operation, numberOfSearches;
    // Variáveis para as strings dos nomes dos arquivos de
    // entrada e de saída
    char *inFileName, *outFileName;

    inFileName = (char*) malloc(15 * sizeof(char));
    outFileName = (char*) malloc(15 * sizeof(char));

    scanf("%d %s", &operation, inFileName);

    switch(operation) {
        // Funcionalidade 1
        case 1:
            scanf("%s", outFileName);
            operation1(inFileName, outFileName);
            break;
        /*case 2:
            // Funcionalidade 2
            operation2(inFileName);
            break;
        case 3:
            // Funcionalidade 3
            scanf("%d", &numberOfSearches);
            operation3(inFileName, numberOfSearches);
            break;*/
        default:
            printf("Falha no processamento do arquivo.");
    }
    
    // Libera a memória alocada
    free(inFileName);
    free(outFileName);
    inFileName = NULL;
    outFileName = NULL;
    
    return 0;
}