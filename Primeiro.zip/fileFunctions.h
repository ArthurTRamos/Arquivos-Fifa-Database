#ifndef FILE_FUNCTIONS_H
    #define FILE_FUNCTIONS_H

    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <stdbool.h>
    #include "registers.h"
    #include "funcoes_fornecidas.h"

    bool readCsvFile(char* inFileName);
    bool writeBinFile(char *outFileName);

#endif