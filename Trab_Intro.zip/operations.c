#include "operations.h"

// Cntrole da operação 1
void Operation1(char* inFileName, char* outFileName) {
    /*HEADER* header = createHeader;
    DATA* data = createData;

    if((header == NULL) || (data == NULL)) {
        printf("Falha no processamento do arquivo.\n");
        return;
    }*/

    // Lê o arquivo .csv e escreve no arquivo .bin
    // Imprime o valor do binário na tela
    if(ReadCsvFile(inFileName) && WriteBinFile(outFileName))
        binarioNaTela(outFileName);
}

// Controle da operação 2
void Operation2(char* inFileName) {
    // Imprime as informações do arquivo binário
    PrintFileInfo(inFileName);
}

// Contole da operação 3
void Operation3(char* inFileName, int numberOfSearches) {
    // Lê arquivo .bin
    // Chama "SearchBinFile" para cada busca pedida
    if(ReadBinFile(inFileName)) {
        for(int i = 0; i < numberOfSearches; i++) {
            printf("Busca %d\n\n", i + 1);
            SearchBinFile(i);
        }
    }
}
