#include "operations.h"

// Cntrole da operação 1
void Operation1(char* inFileName, char* outFileName) {
    // Lê o arquivo .csv e escreve no arquivo .bin
    // Imprime o valor do binário na tela
    if(ReadCsvFile(inFileName) && WriteBinFile(outFileName))
        binarioNaTela(outFileName);
    else
        printf("Falha no processamento do arquivo.\n");
}

// Controle da operação 2
void Operation2(char* inFileName) {
    // Imprime as informações do arquivo binário
    PrintFileInfo(inFileName);
}

// Contole da operação 3
void Operation3(char* inFileName, int numberOfSearches) {
    // Lê arquivo .bin e armazena nos registros
    // Chama "SearchBinFile" para cada busca pedida
    if(ReadBinFile(inFileName)) {
        for(int i = 0; i < numberOfSearches; i++) {
            printf("Busca %d\n\n", i + 1);
            SearchBinFile(i);
        }
    }
    else
        printf("Falha no processamento do arquivo.\n");
}
