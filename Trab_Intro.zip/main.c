/*
    Grupo:
        Arthur Trottmann Ramos - 14681052
        Henrique Drago - 14675441

    Arquivo:
        Programa principal e de leitura de Entradas. Redireciona
        para as operações, funções e procedimentos específicos
*/

#include "operations.h"

int main(void) {
    // Variáveis para o número da funcionalidade (de 1 a 3) e
    // o número de buscas (funcionalidade 3)
    int operation, numberOfSearches;
    // Variáveis para as strings dos nomes dos arquivos de
    // entrada e de saída
    char *inFileName, *outFileName;

    inFileName = (char*) malloc(15 * sizeof(char));
    outFileName = (char*) malloc(15 * sizeof(char));

    scanf("%d %s", &operation, inFileName);

    // Escolha a funcionalidade do programa
    switch(operation) {
        case 1:
            // Funcionalidade 1
            scanf("%s", outFileName);
            Operation1(inFileName, outFileName);
            break;
        case 2:
            // Funcionalidade 2
            Operation2(inFileName);
            break;
        case 3:
            // Funcionalidade 3
            scanf("%d", &numberOfSearches);
            Operation3(inFileName, numberOfSearches);
            break;
        default:
            // Mensagem de Erro
            printf("Falha no processamento do arquivo.\n");
    }
    
    // Libera a memória alocada
    free(inFileName);
    free(outFileName);
    inFileName = NULL;
    outFileName = NULL;
    
    return 0;
}