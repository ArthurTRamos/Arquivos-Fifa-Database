#ifndef OPERATIONS_H
    #define OPERATIONS_H

    /*
        Arquivo:
            Direciona cada funcionalidade para
            suas respectivas funções específicas
    */

    #include "funcoes_fornecidas.h"
    #include "fileFunctions.h"
    
    // Funcionalidade 1
    void Operation1(char* inFileName, char* outFileName);
    
    // Funcionalidade 2
    void Operation2(char* inFileName);
    
    // Funcionalidade 3
    void Operation3(char* inFileName, int numberOfSearches);

#endif