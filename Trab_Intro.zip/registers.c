#include "registers.h"

// Registro de Cabeçalho
struct headerRegister {
    char status; // Consistência do Arquivo ('0'/'1' para instável/estável)
    long long top; // Byte offset de um registro removido
    long long nextByteOffset; // Próximo byte disponível para escrita
    int onRegistersNumber; // Registros não removidos
    int offRegistersNumber; // Registros removidos
};

// Registro de Dados
struct dataRegister {
    char removed; // Registro removido ou não
    int registerSize; // Número de Bytes do registro
    long long nextRegister; // Byte offsete do próximo registro removido
    int playerId; // ID do jogador
    int playerAge; // Idade do jogador
    int playerNameSize;
    char* playerName; // Nome do jogador
    int playerNatSize;
    char* playerNat; // Nacionalidade do jogador
    int playerClubSize;
    char* playerClub; // Clube do jogador
};

HEADER* header;
DATA** data;

// Aloca memória para o registro de cabeçalho
HEADER* CreateHeader() {
    HEADER* newHeader;

    if((newHeader = (HEADER*) malloc(sizeof(HEADER))) == NULL)
        return NULL;

    // Inicializa os campos
    (newHeader->status) = '0';
    newHeader->top = -1;
    newHeader->nextByteOffset = 0;
    newHeader->onRegistersNumber = 0;
    newHeader->offRegistersNumber = 0;

    return newHeader;
}

// Aloca memória para os registros de dados
DATA** CreateData(int registerNumber) {
    DATA** newData;

    if((newData = (DATA**) malloc(registerNumber * sizeof(DATA*))) == NULL)
        return NULL;

    for(int i = 0; i < registerNumber; i++) {
        if((newData[i] = (DATA*) malloc(sizeof(DATA))) == NULL)
            return NULL;

        // Reserva espaço para nome, nacionalidade e
        // clube do jogador do registro
        newData[i]->playerName = (char*) malloc(40 * sizeof(char));
        newData[i]->playerNat = (char*) malloc(40 * sizeof(char));
        newData[i]->playerClub = (char*) malloc(40 * sizeof(char));
    }

    return newData;
}

// Armazena os registros lidos de registers nas structs
// de cabeçalho e de dados
bool StoreCsvInfo(char** registers, int registerNumber) {
    header = CreateHeader();
    data = CreateData(registerNumber);

    if((header == NULL) || (data == NULL))
        return false;

    char field[40]; // Armazenamento temporário de cada campo
    char control; // Contole de término do campo (',')

    // Tamanho dos campos variáveis e 
    // contole do byte offset do próximo registro
    int nameSize, natSize, clubSize, begin;

    // índices das strings de field e da linha lida
    // do arquivo .csv
    int j, stringPerc;

    begin = 25; // Byte Offset do primeiro registro

    // Loop para cada registro de dados
    for(int i = 0; i < registerNumber; i++) {
        j = stringPerc = 0;
        (data[i]->removed) = '0';

        // Armazena o 1º caractere da string
        control = registers[i][stringPerc];

        // Leitura do campo ID
        while(control != ',') {
            field[j] = control;
            j++;
            stringPerc++;
            control = registers[i][stringPerc];
        }

        field[j] = '\0';
        stringPerc++;

        // Converte ID para inteiro e armazena em seu campo
        data[i]->playerId = atoi(field);


        j = 0;
        control = registers[i][stringPerc];

        // Leitura do campo Idade
        while(control != ',') {
            field[j] = control;
            j++;
            stringPerc++;
            control = registers[i][stringPerc];
        }
        
        field[j] = '\0';
        stringPerc++;

        // Verifica se o campo é nulo ou não
        if(j != 0)
            data[i]->playerAge = atoi(field);
        else
            data[i]->playerAge = -1;

        
        j = 0;
        control = registers[i][stringPerc];

        // Leitura do campo nome do jogador
        while(control != ',') {
            field[j] = control;
            j++;
            stringPerc++;
            control = registers[i][stringPerc];
        }

        field[j] = '\0';
        stringPerc++;

        // Verifica se o campo é nulo ou não
        // Se não, atualiza o tamanho do nome e
        // o próprio nome
        if(j != 0) {
            nameSize = strlen(field);
            strcpy(data[i]->playerName, field);
        }
        else {
            nameSize = 0;
            data[i]->playerName = "";
        }

        
        j = 0;
        control = registers[i][stringPerc];

        // Leitura do campo nacionalidade do jogador
        while(control != ',') {
            field[j] = control;
            j++;
            stringPerc++;
            control = registers[i][stringPerc];
        }

        field[j] = '\0';
        stringPerc++;

        // Verifica se o campo é nulo ou não
        // Se não, atualiza o tamanho da nacionalidade e
        // a própria nacionalidade
        if(j != 0) {
            natSize = strlen(field);
            strcpy(data[i]->playerNat, field);
        }
        else {
            natSize = 0;
            data[i]->playerNat = "";
        }

        
        j = 0;
        control = registers[i][stringPerc];

        // Leitura do campo clube do jogador
        while(control != '\0') {
            field[j] = control;
            j++;
            stringPerc++;
            control = registers[i][stringPerc];
        }

        field[j] = '\0';

        // Verifica se o campo é nulo ou não
        // Se não, atualiza o tamanho do clube e
        // o próprio clube
        if(j != 0) {
            clubSize = strlen(field);
            strcpy(data[i]->playerClub, field);
        }
        else {
            clubSize = 0;
            data[i]->playerClub = "";
        }

        // Atualiza os tamanhos dos campos variáveis
        data[i]->playerNameSize = nameSize;
        data[i]->playerNatSize = natSize;
        data[i]->playerClubSize = clubSize;

        // Atualiza o tamanho do registro e o próximo registro removido
        data[i]->registerSize = 33 + nameSize + natSize + clubSize;
        data[i]->nextRegister = -1;

        // Atualiza o byte offset atual
        begin = begin + data[i]->registerSize;

        // Atualiza o cabeçalho com o próximo byte livre e
        // número de registros
        header->nextByteOffset = begin;
        if(data[i]->removed == '0')
            header->onRegistersNumber += 1;
        else
            header->offRegistersNumber += 1;
    }

    // Atualiza o status e o último byte do arquivo
    header->status = '1';
    header->nextByteOffset = begin;
    
    return true;
}

// Escreve o registro de cabeçalho no arquivo .bin
void WriteBinHeader(FILE* outFile) {
    fwrite(&(header->status), sizeof(char), 1, outFile);
    fwrite(&(header->top), sizeof(long long), 1, outFile);
    fwrite(&(header->nextByteOffset), sizeof(long long), 1, outFile);
    fwrite(&(header->onRegistersNumber), sizeof(int), 1, outFile);
    fwrite(&(header->offRegistersNumber), sizeof(int), 1, outFile);
}

// Escreve o registro de dados no arquivo .bin
void WriteBinData(FILE* outFile) {
    for(int i = 0; i < header->onRegistersNumber; i++) {
        fwrite(&(data[i]->removed), sizeof(char), 1, outFile);
        fwrite(&(data[i]->registerSize), sizeof(int), 1, outFile);
        fwrite(&(data[i]->nextRegister), sizeof(long long), 1, outFile);
        fwrite(&(data[i]->playerId), sizeof(int), 1, outFile);
        fwrite(&(data[i]->playerAge), sizeof(int), 1, outFile);
        fwrite(&(data[i]->playerNameSize), sizeof(int), 1, outFile);
        fwrite(data[i]->playerName, data[i]->playerNameSize * sizeof(char), 1, outFile);
        fwrite(&(data[i]->playerNatSize), sizeof(int), 1, outFile);
        fwrite(data[i]->playerNat, data[i]->playerNatSize * sizeof(char), 1, outFile);
        fwrite(&(data[i]->playerClubSize), sizeof(int), 1, outFile);
        fwrite(data[i]->playerClub, data[i]->playerClubSize * sizeof(char), 1, outFile); 
    }

    // Libera memória de data e de header
    FreeMemoryData(&data, header->onRegistersNumber);
    FreeMemoryHeader(&header);
}

// Lê os registros do arquivo .bin e os imprime
void GetData(FILE* inFile, int n_reg) {
    // Usa um registro de dados auxiliar
    DATA* data = (DATA*) malloc(sizeof(DATA));
    // vetor auxiliar para pular um registro removido
    char lixo[200];

    data->playerName = (char*) malloc(40 * sizeof(char));
    data->playerNat = (char*) malloc(40 * sizeof(char));
    data->playerClub = (char*) malloc(40 * sizeof(char));

    // Percorre todos os registros do arquivo
    for(int i = 0; i < n_reg; i++) {
        fread(&(data->removed), 1, 1, inFile);
        fread(&(data->registerSize), 4, 1, inFile);

        // Se for um registro removido, pula para o próximo
        if(data->removed == '1') {
            fread(lixo, data->registerSize - 5, 1, inFile);
            continue;
        }

        // Lê e armazena todas as outras informações do registro de
        // dados
        fread(&(data->nextRegister), sizeof(long long), 1, inFile);
        fread(&(data->playerId), sizeof(int), 1, inFile);
        fread(&(data->playerAge), sizeof(int), 1, inFile);
        fread(&(data->playerNameSize), sizeof(int), 1, inFile);
        fread(data->playerName, data->playerNameSize, 1, inFile);
        (data->playerName)[data->playerNameSize] = '\0';
        fread(&(data->playerNatSize), sizeof(int), 1, inFile);
        fread(data->playerNat, data->playerNatSize, 1, inFile);
        (data->playerNat)[data->playerNatSize] = '\0';
        fread(&(data->playerClubSize), sizeof(int), 1, inFile);
        fread(data->playerClub, data->playerClubSize, 1, inFile);
        (data->playerClub)[data->playerClubSize] = '\0';

        // Imprime as informações pedidas do registro
        PrintData(data);
    }
}

// Imprime nome, nacionalidade e clube do jogador de um
// registro de dados
void PrintData(DATA* data) {
    // Nome
    printf("Nome do Jogador: ");
    if(data->playerNameSize > 0)
        printf("%s\n", data->playerName);
    else
        printf("SEM DADO\n");

    // Nacionalidade
    printf("Nacionalidade do Jogador: ");
    if(data->playerNatSize > 0)
        printf("%s\n", data->playerNat);
    else
        printf("SEM DADO\n");

    // Clube
    printf("Clube do Jogador: ");
    if(data->playerClubSize > 0)
        printf("%s\n\n", data->playerClub);
    else
        printf("SEM DADO\n\n");
}

// Armazena as informações do arquivo .bin em registros
bool StoreBinInfo(FILE* inFile, int totalRegisters) {
    // Aloca memória para o cabeçalho e para os dados
    header = CreateHeader();
    data = CreateData(totalRegisters);

    char status; // Verifica se chegou ao final do arquivo
    int i = 0; // Contola o índice do registro atual

    if(header == NULL || data == NULL)
        return false;

    header->onRegistersNumber = totalRegisters;

    // Lê cada registro do arquivo binário até o fim
    while(fread(&status, sizeof(char), 1, inFile) != 0) {
        // Atualiza o campo "removido"
        data[i]->removed = status;
        
        // Atualiza o tamanho do registro e o próximo registro removido
        fread(&(data[i]->registerSize), sizeof(int), 1, inFile);
        fread(&(data[i]->nextRegister), sizeof(long long), 1, inFile);

        // Atualiza o ID e a idade do jogador
        fread(&(data[i]->playerId), sizeof(int), 1, inFile);
        fread(&(data[i]->playerAge), sizeof(int), 1, inFile);

        // Atualiza os campos variáveis e os tamanhos dos campos

        fread(&(data[i]->playerNameSize), sizeof(int), 1, inFile);
        fread(data[i]->playerName, data[i]->playerNameSize, 1, inFile);
        (data[i]->playerName)[data[i]->playerNameSize] = '\0';

        fread(&(data[i]->playerNatSize), sizeof(int), 1, inFile);
        fread(data[i]->playerNat, data[i]->playerNatSize, 1, inFile);
        (data[i]->playerNat)[data[i]->playerNatSize] = '\0';

        fread(&(data[i]->playerClubSize), sizeof(int), 1, inFile);
        fread(data[i]->playerClub, data[i]->playerClubSize, 1, inFile);
        (data[i]->playerClub)[data[i]->playerClubSize] = '\0';

        i++;
    }

    // Fecha o arquivo binário
    fclose(inFile);
    return true;
}

// Realiza uma busca de campos e seus valores nos registros de dados 
void SearchBinData(int duplas, char** campName, char** campValue, int i) {
    // Variáveis:
    // Contole do número de campos que correspondem à busca
    // Número de registros que correspondem à busca
    // Verifica se ID foi encontrado, caso seja um campo de busca
    int campCounter, regFinded, verifyID;

    int registers = header->onRegistersNumber;
    int totalRegisters = registers + header->offRegistersNumber;

    regFinded = 0;

    // Itera sobre todos os registros
    for(int i = 0; i < totalRegisters; i++) {
        // Verifica se o registro está removido
        if(data[i]->removed == '1')
            continue;

        campCounter = verifyID = 0;
        
        // Itera o registro sobre todos campos pedidos na busca
        for(int j = 0; j < duplas; j++) {
            // Campo de busca ID
            if(strcmp(campName[j], "id") == 0) {
                // Verifica se os dados batem
                if(data[i]->playerId == (atoi(campValue[j]))) {
                    campCounter++;
                    verifyID = 1;
                }
                continue;
            }

            // Campo de busca Idade
            if(strcmp(campName[j], "idade") == 0) {
                // Verifica se os dados batem
                if(data[i]->playerAge == (atoi(campValue[j])))
                    campCounter++;
                continue;
            }

            // Campo de busca nomeJogador
            if(strcmp(campName[j], "nomeJogador") == 0) {
                if(data[i]->playerNameSize == 0)
                    continue;

                // Verifica se os dados batem
                if(strcmp(data[i]->playerName, campValue[j]) == 0)
                    campCounter++;
                continue;
            }

            // Campo de busca nacionalidade
            if(strcmp(campName[j], "nacionalidade") == 0) {
                if(data[i]->playerNatSize == 0)
                    continue;

                // Verifica se os dados batem
                if(strcmp(data[i]->playerNat, campValue[j]) == 0)
                    campCounter++;
                continue;
            }

            // Campo de busca nomeClube
            if(strcmp(campName[j], "nomeClube") == 0) {
                if(data[i]->playerClubSize == 0)
                    continue;

                // Verifica se os dados batem
                if(strcmp(data[i]->playerClub, campValue[j]) == 0)
                    campCounter++;
                continue;
            }
        }

        // Se todos os campos de busca forem encontrados, imprime o registro
        if(campCounter == duplas) {
            if(data[i]->playerNameSize == 0)
                printf("Nome do Jogador: SEM DADO\n");
            else
                printf("Nome do Jogador: %s\n", data[i]->playerName);
                
            if(data[i]->playerNatSize == 0)
                printf("Nacionalidade do Jogador: SEM DADO\n");
            else
                printf("Nacionalidade do Jogador: %s\n", data[i]->playerNat);

            if(data[i]->playerClubSize == 0)
                printf("Clube do Jogador: SEM DADO\n\n");
            else
                printf("Clube do Jogador: %s\n\n", data[i]->playerClub);
                
            regFinded++;
        }

        // Sai do loop se a chave primária (ID) for
        // Encontrada
        else {
            if(verifyID == 1)
                break;
        }
    }

    // Nenhum registro bate com as buscas
    if(regFinded == 0) {
        printf("Registro inexistente.\n\n");
    }

    // Se a última busca for realizada, libera memória dos registros
    if(i == duplas) {
        FreeMemoryHeader(&header);
        FreeMemoryData(&data, registers);
    }
}

// Libera memória alocada para o registro de cabeçalho
void FreeMemoryHeader(HEADER** header) {
    free(*header);
    *header = NULL;
}

// Libera memória alocada para os registros de dados
void FreeMemoryData(DATA*** data, int registers) {
    for(int i = 0; i < registers; i++) {
        if((*data)[i] != NULL) {
            if(((*data)[i]->playerNameSize) != 0)
                free((*data)[i]->playerName);
            if(((*data)[i]->playerNatSize) != 0)
                free((*data)[i]->playerNat);
            if(((*data)[i]->playerClubSize) != 0)
                free((*data)[i]->playerClub);
            free((*data)[i]);
            (*data)[i] = NULL;
        }
    }

    free(*data);
    *data = NULL;
}