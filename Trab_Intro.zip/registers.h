#ifndef REGISTERS_H
    #define REGISTERS_H

    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <stdbool.h>

    typedef struct headerRegister HEADER;
    typedef struct dataRegister DATA;

    /*
        Arquivo:
            Possui as estruturas de dados para os
            registros de cabeçalho e de dados e define
            funções de manipulação desses
    */

    HEADER* createHeader();
    DATA** createData(int registerNumber);
    bool storeCsvInfo(char** registers, int registerNumber);
    void writeBinHeader(FILE* outFile);
    void writeBinData(FILE* outFile);
    void freeMemoryHeader(HEADER** header);
    void freeMemoryData(DATA*** data, int registers);
    void get_data(FILE* inFile, int n_reg);
    void print_data(DATA* data);
    bool storeBinInfo(FILE* inFile, int totalRegisters);
    void searchBinData(int duplas, char** campName, char** campValue, int i);

#endif