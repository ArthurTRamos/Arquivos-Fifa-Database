#ifndef REGISTERS_H
    #define REGISTERS_H

    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <stdbool.h>

    typedef struct headerRegister HEADER;
    typedef struct dataRegister DATA;

    /*
        Arquivo:
            Possui as estruturas de dados para os
            registros de cabeçalho e de dados e define
            funções de manipulação desses
    */

    // Aloca espaço para o registro de cabeçalho
    HEADER* CreateHeader();

    // Aloca espaço para um número de registros de dados
    DATA** CreateData(int registerNumber);

    // Armazena os dados do arquivo .csv nos registros
    bool StoreCsvInfo(char** registers, int registerNumber);

    // Escreve os registros de cabeçalho e de dados no arquivo .bin
    void WriteBinHeader(FILE* outFile);
    void WriteBinData(FILE* outFile);

    // Lê uma quantidade de registros do arquivo .bin
    void GetData(FILE* inFile, int n_reg);

    // Imprime as informações do jogador de um registro
    void PrintData(DATA* data);

    // Armazena os dados do arquivo .bin nos registros
    bool StoreBinInfo(FILE* inFile, int totalRegisters);

    // Faz uma busca i nos registros de dados
    void SearchBinData(int duplas, char** campName, char** campValue, int i);

    // Libera memória dos registros de cabeçalho e de dados
    void FreeMemoryHeader(HEADER** header);
    void FreeMemoryData(DATA*** data, int registers);

#endif