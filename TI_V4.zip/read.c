#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

struct headerRegister {
    char status;
    long long top;
    long long nextByteOffset;
    int onRegistersNumber;
    int offRegistersNumber;
};

struct dataRegister {
    char removed;
    int registerSize;
    long long nextRegister;
    int playerId;
    int playerAge;
    int playerNameSize;
    char* playerName;
    int playerNatSize;
    char* playerNat;
    int playerClubSize;
    char* playerClub;
};

int main() {
    FILE* r = fopen("binario1.bin", "rb");
    struct headerRegister h;
    struct dataRegister d;

    fread(&(h.status), 1, 1, r);
    fread(&(h.top), 8, 1, r);
    fread(&(h.nextByteOffset), 8, 1, r);
    fread(&(h.onRegistersNumber), 4, 1, r);
    fread(&(h.offRegistersNumber), 4, 1, r);

    printf("%c, %Ld, %Ld, %d, %d\n", h.status, h.top, h.nextByteOffset, h.onRegistersNumber, h.offRegistersNumber);

    d.playerName = (char*) malloc(40 * sizeof(char));
    d.playerNat = (char*) malloc(40 * sizeof(char));
    d.playerClub = (char*) malloc(40 * sizeof(char));

    for(int i = 0; i < h.onRegistersNumber + h.offRegistersNumber; i++) {

        fread(&(d.removed), 1, 1, r);
        fread(&(d.registerSize), 4, 1, r);
        fread(&(d.nextRegister), 8, 1, r);
        fread(&(d.playerId), 4, 1, r);
        fread(&(d.playerAge), 4, 1, r);
        fread(&(d.playerNameSize), 4, 1, r);
        fread(d.playerName, d.playerNameSize, 1, r);
        (d.playerName)[d.playerNameSize] = '\0';
        fread(&(d.playerNatSize), 4, 1, r);
        fread(d.playerNat, d.playerNatSize, 1, r);
        (d.playerNat)[d.playerNatSize] = '\0';
        fread(&(d.playerClubSize), 4, 1, r);
        fread(d.playerClub, d.playerClubSize, 1, r);
        (d.playerClub)[d.playerClubSize] = '\0';

        printf("%c, %d, %Ld, %d, %d\n", d.removed, d.registerSize, d.nextRegister, d.playerId, d.playerAge);
        printf("%d, %s, %d, %s, %d, %s\n", d.playerNameSize, d.playerName, d.playerNatSize, d.playerNat, d.playerClubSize, d.playerClub);
    
    }

    fclose(r);

    return 0;
}