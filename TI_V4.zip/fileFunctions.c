#include "fileFunctions.h"

bool readCsvFile(char* inFileName) {
    FILE* inFile;
    int registerNumber, stringSize;
    char** registers;
    char lixo[50];

    registerNumber = 0;

    if((inFile = fopen(inFileName, "r")) == NULL) {
        printf("Falha no processamento do arquivo.");
        return false;
    }

    if(((registers = (char**) malloc(1002 * sizeof(char*))) == NULL)) {
        printf("Falha no processamento do arquivo.");
        return false;
    }
    
    for(int i = 0; i < 1002; i++) {
        if((registers[i] = (char*) malloc(85 * sizeof(char))) == NULL) {
            printf("Falha no processamento do arquivo.");
            free(registers);
            registers = NULL;
            return false;
        }
    }
    
    fgets(lixo, 50, inFile);

    while(fgets(registers[registerNumber], 85, inFile) != NULL) {
        stringSize = strlen(registers[registerNumber]);
        registers[registerNumber][stringSize - 1] = '\0';
        registerNumber++;
    }

    if(!storeCsvInfo(registers, registerNumber)) {
        printf("Falha no processamento do arquivo.");
        return false;
    }

    fclose(inFile);
    
    for(int i = 0; i < 1002; i++) {
        free(registers[i]);
        registers[i] = NULL;
    }

    free(registers);
    registers = NULL;

    return true;
}

bool writeBinFile(char *outFileName) {
    FILE* outFile;

    if((outFile = fopen(outFileName, "wb")) == NULL) {
        printf("Falha no processamento do arquivo.");
        return false;
    }   

    writeBinHeader(outFile);
    writeBinData(outFile);

    fclose(outFile);
    
    return true;
}

void printFileInfo(char *inFileName) {
    FILE* inFile;
    char lixo[17];
    int on, off, n_reg;

    if((inFile = fopen(inFileName, "rb")) == NULL) {
        printf("Falha no processamento do arquivo.");
        return;
    }

    fread(lixo, 17, 1, inFile);
    fread(&on, 4, 1, inFile);
    fread(&off, 4, 1, inFile);
    n_reg = on + off;

    if(on > 0) {
        get_data(inFile, n_reg);
    } else {
        printf("Registro inexistente.");
    }
}