#ifndef OPERATIONS_H
    #define OPERATIONS_H

    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include "funcoes_fornecidas.h"
    #include "fileFunctions.h" 
    
    void operation1(char* inFileName, char* outFileName);
    void operation2(char* inFileName);
    //void operation3(char* inFileName, int numberOfSearches);

#endif